# Fuentes locales

Este proyecto carga Inter y Playfair Display desde Google Fonts por defecto
(ver el @import al inicio de `src/index.css`).

Si vas a usar tus propios archivos de fuente:

1. Copia aquí tus archivos `.woff2` / `.woff`, por ejemplo:
   - Inter-Regular.woff2, Inter-Medium.woff2, Inter-SemiBold.woff2, Inter-Bold.woff2
   - PlayfairDisplay-Italic.woff2, PlayfairDisplay-MediumItalic.woff2, PlayfairDisplay-SemiBoldItalic.woff2

2. En `src/index.css`, reemplaza el `@import url('https://fonts.googleapis.com/...')`
   por bloques `@font-face` que apunten aquí, por ejemplo:

   @font-face {
     font-family: 'Inter';
     src: url('./assets/fonts/Inter-Regular.woff2') format('woff2');
     font-weight: 400;
     font-style: normal;
     font-display: swap;
   }

   Repite un bloque por cada peso/estilo que necesites (300, 400, 500, 600, 700
   para Inter; 400, 500, 600 en itálica para Playfair Display).

No es necesario tocar ningún componente: todos usan `font-family: 'Inter', sans-serif`
y la clase `.font-playfair`, que ya apuntan a estos nombres de fuente.
